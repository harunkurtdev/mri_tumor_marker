### This project is a project created for our Yıldız Technical University mkt4830 course.


## Our Consept
![main_screen](./images/ui/main_screen.png)

## Our Consept
![main_screen_finish](./images/ui/main_screen_finish.PNG)